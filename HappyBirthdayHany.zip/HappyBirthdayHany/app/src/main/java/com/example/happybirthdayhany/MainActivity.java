package com.example.happybirthdayhany;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.happybirthdayhany.R;

public class MainActivity extends AppCompatActivity {

    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("MainActivity", "Hello World");
        Log.d(LOG_TAG,  "ERROR");
        Log.d(LOG_TAG,  "WARNING");
        Log.d(LOG_TAG,  "INFO");
        Log.d(LOG_TAG,  "VERBOSE");
    }
}